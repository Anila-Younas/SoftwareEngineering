#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <string>
#include <map>
#include <mutex>
#include <thread>

using namespace std;

// Forward declarations
class Ant;
class Worker;
template <typename AntType> class Antfarm;
class Colony;
class Meadow;

// Meadow singleton class to manage colonies
class Meadow {
private:
    static Meadow* instance;
    static std::mutex mutex_;
    map<int, Antfarm<Ant>*> colonies;
    int nextColonyId;

    Meadow() : nextColonyId(1) {}

public:
    static Meadow* getInstance() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!instance) {
            instance = new Meadow();
        }
        return instance;
    }

    int addColony(Antfarm<Ant>* farm) {
        int colonyId = nextColonyId++;
        colonies[colonyId] = farm;
        return colonyId;
    }

    Antfarm<Ant>* getColony(int id) {
        if (colonies.find(id) != colonies.end()) {
            return colonies[id];
        }
        return nullptr;
    }

    void checkColonyCount() {
        if (colonies.size() == 1) {
            cout << "Only one colony remains! Ending simulation.\n";
            exit(0);
        }
    }
};

Meadow* Meadow::instance = nullptr;
std::mutex Meadow::mutex_;

// Abstract class for Ant
class Ant {
protected:
    bool isResting;
    bool hasFood;
    int health;

public:
    virtual string getType() = 0;
    virtual void action() = 0;
    virtual void rest() = 0;
    virtual void battle(Ant* opponent) = 0;
    virtual void consumeFood() {
        if (hasFood) {
            cout << "Ant consumes food.\n";
            hasFood = false;
        } else {
            cout << "Ant has no food to consume.\n";
        }
    }

    virtual void gatherFood() {
        hasFood = true;
        cout << "Ant gathers food.\n";
    }

    void reduceHealth(int damage) {
        health -= damage;
        if (health <= 0) {
            cout << "Ant has died.\n";
        }
    }

    virtual ~Ant() {}
};

// Worker class definition
class Worker : public Ant {
public:
    Worker() { health = 10; }

    string getType() override { return "Worker"; }

    void action() override {
        if (!isResting) {
            gatherFood();
        }
    }

    void rest() override {
        isResting = true;
        cout << "Worker is resting.\n";
    }

    void battle(Ant* opponent) override {
        cout << "Worker is battling " << opponent->getType() << ".\n";
        reduceHealth(2);  // Example damage
    }
};

// Drone class definition
class Drone : public Ant {
public:
    Drone() { health = 8; }

    string getType() override { return "Drone"; }

    void action() override {
        if (!isResting) {
            gatherFood();
        }
    }

    void rest() override {
        isResting = true;
        cout << "Drone is resting.\n";
    }

    void battle(Ant* opponent) override {
        cout << "Drone is battling " << opponent->getType() << ".\n";
        reduceHealth(3);  // Example damage
    }
};

// Warrior class definition
class Warrior : public Ant {
public:
    Warrior() { health = 12; }

    string getType() override { return "Warrior"; }

    void action() override {
        if (!isResting) {
            gatherFood();
        }
    }

    void rest() override {
        isResting = true;
        cout << "Warrior is resting.\n";
    }

    void battle(Ant* opponent) override {
        cout << "Warrior is battling " << opponent->getType() << ".\n";
        reduceHealth(4);  // Example damage
    }
};

// Queen class definition
class Queen : public Ant {
public:
    Queen() { health = 15; }

    string getType() override { return "Queen"; }

    void action() override {
        cout << "Queen is spawning an egg.\n";
    }

    void rest() override {
        isResting = true;
        cout << "Queen is resting.\n";
    }

    void battle(Ant* opponent) override {
        cout << "Queen is battling " << opponent->getType() << ".\n";
        reduceHealth(5);  // Example damage
    }
};

// Ant factory to create ants
class AntFactory {
public:
    static Ant* createAnt(const string& type) {
        if (type == "Worker") {
            return new Worker();
        } else if (type == "Drone") {
            return new Drone();
        } else if (type == "Warrior") {
            return new Warrior();
        } else if (type == "Queen") {
            return new Queen();
        }
        return nullptr;
    }
};

// Room class definition
class Room {
private:
    string type;
    int capacity;
    int currentOccupants;

public:
    Room(const string& type, int capacity) : type(type), capacity(capacity), currentOccupants(0) {}

    string getType() { return type; }
    int getCapacity() { return capacity; }

    bool canRest() {
        return currentOccupants < capacity;
    }

    void addOccupant() {
        if (canRest()) {
            currentOccupants++;
        } else {
            cout << "Room is at full capacity!\n";
        }
    }

    int getCurrentOccupants() { return currentOccupants; }
};

// Antfarm template class to manage ants and rooms
template <typename AntType>
class Antfarm {
private:
    vector<AntType*> ants;
    vector<Room> rooms;
    bool queenAlive;
    string species;

public:
    Antfarm(const string& species) : species(species), queenAlive(true) {}

    void addAnt(AntType* ant) {
        if (ant->getType() == "Queen" && !queenAlive) {
            cout << "Colony already has a queen!\n";
            return;
        }
        ants.push_back(ant);
    }

    void addRoom(const string& type, int capacity) {
        rooms.push_back(Room(type, capacity));
    }

    void contributeWorkerTicks() {
        for (auto& ant : ants) {
            if (Worker* worker = dynamic_cast<Worker*>(ant)) {
                cout << "Worker ant is contributing to room construction.\n";
            }
        }
    }

    void showAnts() {
        for (auto& ant : ants) {
            cout << ant->getType() << endl;
        }
    }

    void tick() {
        for (auto& ant : ants) {
            ant->action();
            ant->consumeFood();
            ant->rest();
        }
    }

    void checkColonyInteraction(Antfarm<Ant>* enemyFarm) {
        // Battle interaction: queen dies, colony can take over
        for (auto& ant : ants) {
            if (Queen* queen = dynamic_cast<Queen*>(ant)) {
                if (queen->getType() == "Queen") {
                    cout << "A battle started! Queens will fight!\n";
                    enemyFarm->killQueen();
                    queenAlive = false;
                }
            }
        }
    }

    void killQueen() {
        queenAlive = false;
        cout << "Queen has died!\n";
    }

    vector<AntType*>& getAnts() {
        return ants;
    }

    string getSpecies() {
        return species;
    }

    void addResources(const string& resource, int amount) {
        // This is a basic placeholder; extend this for handling food, warriors, etc.
        cout << amount << " " << resource << " added to colony.\n";
    }

    ~Antfarm() {
        for (auto& ant : ants) {
            delete ant;
        }
    }
};

// Mediator class for simulation
class Mediator {
private:
    Antfarm<Ant>* antfarm;

public:
    Mediator(Antfarm<Ant>* antfarm) : antfarm(antfarm) {}

    void runSimulation() {
        cout << "Running simulation...\n";
    }

    void startBattle(Ant* ant1, Ant* ant2) {
        ant1->battle(ant2);
    }
};

// Command function implementations
void spawnColony(Meadow* meadow, const string& species) {
    Antfarm<Ant>* farm = new Antfarm<Ant>(species);
    int colonyId = meadow->addColony(farm);
    cout << "Colony " << colonyId << " created for species: " << species << ".\n";
}

void giveResource(Antfarm<Ant>* colony, const string& resource, int amount) {
    colony->addResources(resource, amount);
}

void tickColony(Antfarm<Ant>* colony, int ticks = 1) {
    for (int i = 0; i < ticks; ++i) {
        colony->tick();
    }
    cout << ticks << " tick(s) completed.\n";
}

void summarizeColony(Antfarm<Ant>* colony) {
    cout << "Species: " << colony->getSpecies() << endl;
    colony->showAnts();
}

// Main program to interact with the interface
int main() {
    Meadow* meadow = Meadow::getInstance();
    int colonyChoice;

    while (true) {
        cout << "Menu:\n1. Spawn colony\n2. Give resources\n3. Tick\n4. Show colony\n5. Exit\n";
        cout << "Enter choice: ";
        cin >> colonyChoice;

        if (colonyChoice == 1) {
            string species;
            cout << "Enter species (e.g., Worker, Drone, Queen): ";
            cin >> species;
            spawnColony(meadow, species);
        } else if (colonyChoice == 2) {
            int colonyId;
            string resource;
            int amount;
            cout << "Enter colony ID: ";
            cin >> colonyId;
            cout << "Enter resource: ";
            cin >> resource;
            cout << "Enter amount: ";
            cin >> amount;

            Antfarm<Ant>* colony = meadow->getColony(colonyId);
            if (colony != nullptr) {
                giveResource(colony, resource, amount);
            } else {
                cout << "Invalid colony ID.\n";
            }
        } else if (colonyChoice == 3) {
            int colonyId, ticks;
            cout << "Enter colony ID: ";
            cin >> colonyId;
            cout << "Enter number of ticks: ";
            cin >> ticks;

            Antfarm<Ant>* colony = meadow->getColony(colonyId);
            if (colony != nullptr) {
                tickColony(colony, ticks);
            } else {
                cout << "Invalid colony ID.\n";
            }
        } else if (colonyChoice == 4) {
            int colonyId;
            cout << "Enter colony ID to show: ";
            cin >> colonyId;

            Antfarm<Ant>* colony = meadow->getColony(colonyId);
            if (colony != nullptr) {
                summarizeColony(colony);
            } else {
                cout << "Invalid colony ID.\n";
            }
        } else if (colonyChoice == 5) {
            cout << "Exiting simulation. Goodbye!\n";
            break;
        } else {
            cout << "Invalid choice. Please try again.\n";
        }
    }
}
